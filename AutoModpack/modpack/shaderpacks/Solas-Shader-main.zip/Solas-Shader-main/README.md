# Solas-Shader
A good performing fantasy stylised shaderpack with fancy visuals!
![solas](https://user-images.githubusercontent.com/83358692/171504685-ba602d22-9010-4e8b-be79-45ec8ae2d997.png)
